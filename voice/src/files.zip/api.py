import os
import sys
import uuid
import time
import logging
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv
from livekit.api import AccessToken, VideoGrants
from groq import Groq

sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
from rag.retriever import SmartRetriever

load_dotenv(".env.local")
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("narad.api")

# ── Clients ───────────────────────────────────────────────────────────────────
LIVEKIT_URL        = os.getenv("LIVEKIT_URL")
LIVEKIT_API_KEY    = os.getenv("LIVEKIT_API_KEY")
LIVEKIT_API_SECRET = os.getenv("LIVEKIT_API_SECRET")
groq_client        = Groq(api_key=os.getenv("GROQ_API_KEY"))

logger.info("Loading SmartRetriever...")
retriever = SmartRetriever()
logger.info("SmartRetriever ready")

# ── App ───────────────────────────────────────────────────────────────────────
app = FastAPI(title="Narad API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Request models ────────────────────────────────────────────────────────────
class TokenRequest(BaseModel):
    user_id: Optional[str] = None
    room_name: Optional[str] = "narad-room"

class ChatRequest(BaseModel):
    message: str
    language: Optional[str] = "hinglish"  # hi | en | hinglish

class RAGRequest(BaseModel):
    query: str
    top_k: Optional[int] = 3

# ── /health ───────────────────────────────────────────────────────────────────
@app.get("/health")
def health():
    return {
        "status": "ok",
        "services": {
            "groq":    bool(os.getenv("GROQ_API_KEY")),
            "livekit": bool(LIVEKIT_API_KEY),
            "rag":     retriever is not None,
        },
    }

# ── /token ────────────────────────────────────────────────────────────────────
@app.post("/token")
def get_token(req: TokenRequest):
    """Issue a LiveKit JWT for joining a voice session room."""
    if not LIVEKIT_API_KEY or not LIVEKIT_API_SECRET:
        raise HTTPException(status_code=500, detail="LiveKit credentials not set in .env.local")

    user_id = req.user_id or f"user-{uuid.uuid4().hex[:8]}"

    token = (
        AccessToken(LIVEKIT_API_KEY, LIVEKIT_API_SECRET)
        .with_identity(user_id)
        .with_name(user_id)
        .with_grants(VideoGrants(room_join=True, room=req.room_name))
        .to_jwt()
    )

    logger.info(f"Token issued → user={user_id} room={req.room_name}")
    return {
        "token":       token,
        "room_name":   req.room_name,
        "user_id":     user_id,
        "livekit_url": LIVEKIT_URL,
    }

# ── /chat ─────────────────────────────────────────────────────────────────────
@app.post("/chat")
def chat(req: ChatRequest):
    """Text chat with Narad — RAG lookup + Groq LLM response."""
    t = time.perf_counter()

    # RAG
    rag_context, rag_domain = "", ""
    try:
        domain, docs = retriever.retrieve(req.message)
        rag_context = "\n".join(
            [d.get("text", d.get("answer", "")) for d in docs[:3]]
        )[:1500]
        rag_domain = domain
    except Exception as e:
        logger.warning(f"RAG failed: {e}")

    # Language instruction
    lang_map = {
        "hi":       "Always respond in natural Hindi using Devanagari script.",
        "en":       "Always respond in clear English.",
        "hinglish": "Always respond in Hinglish (mix of Hindi and English).",
    }
    lang_instr = lang_map.get(req.language, lang_map["hinglish"])

    # Groq
    try:
        resp = groq_client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[
                {
                    "role": "system",
                    "content": (
                        f"You are Narad, a helpful assistant for rural governance in India. "
                        f"{lang_instr} "
                        f"Give complete, helpful answers in 3-4 sentences. "
                        f"No bullet points or formatting — plain conversational text only."
                        + (f"\n\nContext from knowledge base:\n{rag_context}" if rag_context else "")
                    ),
                },
                {"role": "user", "content": req.message},
            ],
            max_tokens=300,
            temperature=0.7,
        )
    except Exception as e:
        logger.error(f"Groq error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

    return {
        "reply":       resp.choices[0].message.content.strip(),
        "rag_domain":  rag_domain,
        "rag_used":    bool(rag_context),
        "latency_ms":  round((time.perf_counter() - t) * 1000),
        "tokens_used": resp.usage.total_tokens,
    }

# ── /rag ──────────────────────────────────────────────────────────────────────
@app.post("/rag")
def rag_search(req: RAGRequest):
    """Raw retriever query — returns docs for debugging."""
    t = time.perf_counter()
    try:
        domain, docs = retriever.retrieve(req.query)
        return {
            "query":      req.query,
            "domain":     domain,
            "latency_ms": round((time.perf_counter() - t) * 1000),
            "results": [
                {
                    "rank":  i + 1,
                    "text":  d.get("text", d.get("answer", ""))[:600],
                    "score": d.get("score"),
                }
                for i, d in enumerate(docs[: req.top_k])
            ],
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000, reload=True)
