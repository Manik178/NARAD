import streamlit as st
import requests

API_URL = "http://localhost:8000"

st.set_page_config(
    page_title="Narad — Test Console",
    page_icon="🪔",
    layout="wide",
)

# ── Styles ────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Tiro+Devanagari+Hindi&family=JetBrains+Mono:wght@400;600&family=DM+Sans:wght@400;500;600&display=swap');

:root {
    --saffron: #FF6B00;
    --gold:    #FFB300;
    --deep:    #0F0800;
    --surface: #1A0E04;
    --card:    #221208;
    --border:  #3A1E08;
    --text:    #F0DEC8;
    --muted:   #7A5A3A;
    --green:   #4CAF82;
    --red:     #E05252;
    --blue:    #5B9BD5;
}

html, body, [class*="css"] {
    font-family: 'DM Sans', sans-serif !important;
    background: var(--deep) !important;
    color: var(--text) !important;
}
.stApp { background: var(--deep) !important; }

/* Header */
.header {
    background: linear-gradient(120deg, #200E02, #150800);
    border: 1px solid var(--border);
    border-radius: 14px;
    padding: 22px 28px;
    margin-bottom: 28px;
    display: flex;
    align-items: center;
    gap: 18px;
}
.header-title { font-size: 26px; font-weight: 700; color: var(--saffron); margin: 0; }
.header-sub   { font-size: 12px; color: var(--muted); margin: 3px 0 0; font-family: 'JetBrains Mono', monospace; }

/* Status pills */
.pill {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: 20px;
    padding: 3px 12px;
    font-size: 12px;
    font-family: 'JetBrains Mono', monospace;
}
.dot-ok  { color: var(--green); }
.dot-err { color: var(--red); }

/* Method badge */
.badge {
    display: inline-block;
    padding: 1px 8px;
    border-radius: 4px;
    font-size: 11px;
    font-weight: 700;
    font-family: 'JetBrains Mono', monospace;
}
.post { background: #112211; color: var(--green); border: 1px solid #224422; }
.get  { background: #111A2A; color: var(--blue);  border: 1px solid #223344; }

/* Metric row */
.metrics {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    margin: 10px 0 4px;
}
.chip {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 5px;
    padding: 3px 10px;
    font-size: 11px;
    font-family: 'JetBrains Mono', monospace;
    color: var(--muted);
}
.chip b { color: var(--gold); }

/* Hindi text */
.hindi {
    background: linear-gradient(135deg, #1a0d04, #1e1006);
    border: 1px solid var(--border);
    border-left: 3px solid var(--gold);
    border-radius: 10px;
    padding: 16px 20px;
    font-family: 'Tiro Devanagari Hindi', serif;
    font-size: 17px;
    line-height: 1.9;
    color: var(--text);
    margin: 8px 0 4px;
}

/* Code box */
.codebox {
    background: #080400;
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 12px 16px;
    font-family: 'JetBrains Mono', monospace;
    font-size: 12px;
    color: #C8B090;
    word-break: break-all;
    margin: 6px 0;
}

/* Chat bubbles */
.bubble-user {
    text-align: right;
    margin: 6px 0;
}
.bubble-user span {
    display: inline-block;
    background: var(--card);
    border: 1px solid var(--border);
    padding: 8px 14px;
    border-radius: 14px 14px 2px 14px;
    font-size: 14px;
    max-width: 75%;
}

/* Streamlit widget overrides */
.stTextInput > div > div > input,
.stTextArea > div > div > textarea {
    background: var(--surface) !important;
    border: 1px solid var(--border) !important;
    color: var(--text) !important;
    border-radius: 8px !important;
    font-family: 'DM Sans', sans-serif !important;
}
.stSelectbox > div > div { background: var(--surface) !important; }
.stButton > button {
    background: var(--saffron) !important;
    color: #fff !important;
    border: none !important;
    border-radius: 8px !important;
    font-weight: 600 !important;
    font-family: 'DM Sans', sans-serif !important;
}
.stButton > button:hover { background: #e05e00 !important; }
div[data-testid="stTabs"] button { color: var(--muted) !important; }
div[data-testid="stTabs"] button[aria-selected="true"] {
    color: var(--saffron) !important;
    border-bottom-color: var(--saffron) !important;
}
.stExpander { border: 1px solid var(--border) !important; border-radius: 8px !important; }
</style>
""", unsafe_allow_html=True)


# ── Header ────────────────────────────────────────────────────────────────────
st.markdown("""
<div class="header">
    <span style="font-size:38px">🪔</span>
    <div>
        <p class="header-title">Narad — Test Console</p>
        <p class="header-sub">Rural Governance Voice Agent · LiveKit + Groq + RAG</p>
    </div>
</div>
""", unsafe_allow_html=True)


# ── Health bar ────────────────────────────────────────────────────────────────
try:
    h = requests.get(f"{API_URL}/health", timeout=3).json()
    svc = h.get("services", {})
    pills_html = ""
    for name, ok in [("API", True), ("Groq", svc.get("groq")), ("LiveKit", svc.get("livekit")), ("RAG", svc.get("rag"))]:
        dot  = f'<span class="dot-ok">●</span>' if ok else f'<span class="dot-err">●</span>'
        pills_html += f'<span class="pill">{dot} {name}</span> '
    st.markdown(f"<div style='margin-bottom:24px;display:flex;gap:8px;flex-wrap:wrap'>{pills_html}</div>", unsafe_allow_html=True)
except Exception:
    st.error("⚠️  API unreachable — run `python api.py` first on port 8000")
    st.stop()


# ── Tabs ──────────────────────────────────────────────────────────────────────
tab1, tab2, tab3 = st.tabs(["🎙️  Voice Session", "💬  Text Chat", "🔍  RAG Search"])


# ════════════════════════════════════════════════════════
# Tab 1 — Voice Session
# ════════════════════════════════════════════════════════
with tab1:
    st.markdown("### 🎙️ Start Voice Session")
    st.markdown("<span class='badge post'>POST</span> &nbsp;`/token`", unsafe_allow_html=True)
    st.caption("Gets a signed LiveKit JWT. Paste it into the LiveKit Playground or use it with the SDK to connect to Narad.")

    col1, col2 = st.columns(2)
    with col1:
        uid  = st.text_input("User ID", placeholder="leave blank to auto-generate", key="uid")
    with col2:
        room = st.text_input("Room Name", value="narad-room", key="room")

    if st.button("Get Token →", key="token_btn"):
        with st.spinner("Requesting..."):
            try:
                r    = requests.post(f"{API_URL}/token", json={"user_id": uid or None, "room_name": room})
                data = r.json()
            except Exception as e:
                st.error(f"Request failed: {e}")
                data = None

        if data and r.status_code == 200:
            st.success("Token issued ✓")
            st.markdown(f"""
            <div class="metrics">
                <div class="chip">user_id <b>{data['user_id']}</b></div>
                <div class="chip">room <b>{data['room_name']}</b></div>
            </div>
            """, unsafe_allow_html=True)

            st.markdown("**LiveKit URL**")
            st.markdown(f"<div class='codebox'>{data['livekit_url']}</div>", unsafe_allow_html=True)

            st.markdown("**JWT Token**")
            st.markdown(f"<div class='codebox'>{data['token'][:100]}…</div>", unsafe_allow_html=True)

            st.info("💡 Go to **cloud.livekit.io → Playground**, paste the URL + token above, and start speaking to Narad.")

            with st.expander("Full token (copy)"):
                st.code(data["token"], language=None)
        elif data:
            st.error(f"Error {r.status_code}: {data}")


# ════════════════════════════════════════════════════════
# Tab 2 — Text Chat
# ════════════════════════════════════════════════════════
with tab2:
    st.markdown("### 💬 Chat with Narad")
    st.markdown("<span class='badge post'>POST</span> &nbsp;`/chat`", unsafe_allow_html=True)

    if "history" not in st.session_state:
        st.session_state.history = []

    lang = st.selectbox(
        "Response language",
        ["hinglish", "hi", "en"],
        format_func=lambda x: {"hi": "🇮🇳 Hindi", "en": "🇬🇧 English", "hinglish": "🤝 Hinglish"}[x],
        key="lang",
    )

    # Render history
    for msg in st.session_state.history:
        if msg["role"] == "user":
            st.markdown(f"<div class='bubble-user'><span>{msg['content']}</span></div>", unsafe_allow_html=True)
        else:
            st.markdown(f"<div class='hindi'>{msg['content']}</div>", unsafe_allow_html=True)
            if msg.get("meta"):
                m = msg["meta"]
                rag_label = f"✓ {m['rag_domain']}" if m.get("rag_used") else "✗ not used"
                st.markdown(f"""
                <div class="metrics">
                    <div class="chip">⏱ <b>{m['latency_ms']}ms</b></div>
                    <div class="chip">tokens <b>{m['tokens_used']}</b></div>
                    <div class="chip">RAG <b>{rag_label}</b></div>
                </div>
                """, unsafe_allow_html=True)

    # Input form
    with st.form("chat", clear_on_submit=True):
        msg  = st.text_input("Message", placeholder="मेरे गांव में बिजली नहीं आ रही...", label_visibility="collapsed")
        send = st.form_submit_button("Send →")

    if send and msg.strip():
        st.session_state.history.append({"role": "user", "content": msg})
        with st.spinner("Narad is thinking..."):
            try:
                r    = requests.post(f"{API_URL}/chat", json={"message": msg, "language": lang})
                data = r.json()
            except Exception as e:
                st.error(f"Request failed: {e}")
                data = None

        if data and r.status_code == 200:
            st.session_state.history.append({"role": "assistant", "content": data["reply"], "meta": data})
        elif data:
            st.error(f"Error {r.status_code}: {data}")
        st.rerun()

    if st.button("Clear chat", key="clear"):
        st.session_state.history = []
        st.rerun()


# ════════════════════════════════════════════════════════
# Tab 3 — RAG Search
# ════════════════════════════════════════════════════════
with tab3:
    st.markdown("### 🔍 RAG Knowledge Base")
    st.markdown("<span class='badge post'>POST</span> &nbsp;`/rag`", unsafe_allow_html=True)
    st.caption("Directly inspect what your SmartRetriever returns for any query.")

    col1, col2 = st.columns([5, 1])
    with col1:
        query = st.text_input("Query", placeholder="What is PM Kisan Samman Nidhi?", key="rag_q", label_visibility="collapsed")
    with col2:
        top_k = st.number_input("Top K", 1, 10, 3, key="topk", label_visibility="collapsed")

    if st.button("Search →", key="rag_btn"):
        if not query.strip():
            st.warning("Enter a query.")
        else:
            with st.spinner("Retrieving..."):
                try:
                    r    = requests.post(f"{API_URL}/rag", json={"query": query, "top_k": top_k})
                    data = r.json()
                except Exception as e:
                    st.error(f"Request failed: {e}")
                    data = None

            if data and r.status_code == 200:
                st.markdown(f"""
                <div class="metrics">
                    <div class="chip">domain <b>{data['domain']}</b></div>
                    <div class="chip">⏱ <b>{data['latency_ms']}ms</b></div>
                    <div class="chip">results <b>{len(data['results'])}</b></div>
                </div>
                """, unsafe_allow_html=True)

                for doc in data["results"]:
                    with st.expander(f"Result #{doc['rank']}  ·  score: {round(doc['score'], 4) if doc.get('score') else 'n/a'}"):
                        st.markdown(f"<div class='codebox'>{doc['text']}</div>", unsafe_allow_html=True)
            elif data:
                st.error(f"Error {r.status_code}: {data}")
